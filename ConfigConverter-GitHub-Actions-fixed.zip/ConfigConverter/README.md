# Config Converter

Native Android utility for local conversion of VMess, VLESS and Trojan links into V2Ray/Xray JSON and OpenClash YAML.

## Build from Android phone with GitHub Actions

1. Create a GitHub repository.
2. Upload the complete project folder contents.
3. Make sure `.github/workflows/build-apk.yml` is uploaded.
4. Open the repository's **Actions** tab.
5. Select **Build Config Converter APK**.
6. Tap **Run workflow**.
7. Wait for the build to finish.
8. Open the completed workflow run.
9. Download the artifact named **ConfigConverter-debug**.
10. Extract it and install `app-debug.apk` on Android.

The workflow runs tests before building the APK.

## Local build

With JDK 17 and Android SDK:

`gradle test`

`gradle assembleDebug`

## Security

Parsing and conversion are local. The app does not require a backend for config parsing. Credentials are not written to application logs by the supplied code.
